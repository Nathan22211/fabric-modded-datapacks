var GameruleTweaker = libcd.require("libgamerule.GameruleTweaker");
GameruleTweaker.addGamerule("DoCustomMobSpawning", "boolean", true);
GameruleTweaker.addGamerule("CustomRegen", "boolean", true);